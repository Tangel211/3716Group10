
public class RequestData {

}
