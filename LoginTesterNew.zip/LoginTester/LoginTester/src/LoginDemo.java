 
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.PrintStream;
import java.util.Scanner;
import java.awt.event.*;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.text.DateFormat;
import java.time.*;
  
class Login extends JFrame implements ActionListener
 {
  JButton SUBMIT;
  JPanel panel;
  JLabel label1,label2;
  final JTextField  text1,text2;
   Login()
   {
   label1 = new JLabel();
   label1.setText("Username:");
   text1 = new JTextField(15);
 
   label2 = new JLabel();
   label2.setText("Password:");
   text2 = new JPasswordField(15);
  
   SUBMIT=new JButton("SUBMIT");
   
   panel = new JPanel(new GridLayout(3,1));
   panel.add(label1);
   panel.add(text1);
   panel.add(label2);
   panel.add(text2);
   panel.add(SUBMIT);
   add(panel,BorderLayout.CENTER);
   SUBMIT.addActionListener(this);
   setTitle("LOGIN FORM");
   new TableApp3715();
   TableApp3715.window.setVisible(false);
   }
  public void actionPerformed(ActionEvent ae)
   {
   String value1=text1.getText();
   String value2=text2.getText();
   if (value1.equals("Principal") && value2.equals("1")) {
	   JFrame principal = new JFrame();
	   principal.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE );
	   principal.setTitle("Principal");
	   principal.setSize(150, 200);
	   JPanel principalPanel = new JPanel();
	   
	   
	   JButton viewP = new JButton("View Schedule");
	   	 viewP.addActionListener((ActionEvent event) -> {
	   		TableApp3715.table.setEnabled(true);
	   		 TableApp3715.window.setVisible(true);
	   	 });
	   JButton quitP = new JButton("Logout");
     	quitP.addActionListener((ActionEvent event) -> {
            principal.dispose();
        	});
	   principalPanel.add(viewP);
	   principalPanel.add(quitP);
	   principal.add(principalPanel);
	   principal.setVisible(true);
   }
   else if (value1.equals("Requestee") && value2.equals("2")) {
	   JFrame requestee = new JFrame();
	   requestee.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE );
	   requestee.setTitle("Requestee");
	   requestee.setSize(150, 200);
	   JPanel requesteePanel = new JPanel();
	   
	   JButton viewR = new JButton("View Schedule");
	   	 viewR.addActionListener((ActionEvent event) -> {
	   		TableApp3715.table.setEnabled(false);
	   		TableApp3715.window.setVisible(true);
	   	 });
	   JButton reqR = new JButton("Request Timeslot");
	   	 reqR.addActionListener((ActionEvent event) -> {
	   		 JFrame requestData = new JFrame();
	   		 requestData.setTitle("Request Timeslot");
	   		 requestData.setSize(500, 500);
	   		 requestData.setLocationRelativeTo(null);
	   		 requestData.setVisible(true);
	   		 
	   		 JPanel req = new JPanel();
	   		 req.setSize(500, 500);
	   		 req.setVisible(true);
	   		 
	   		 JTextField loc = new JTextField();
	   		 loc.setBounds(100, 100, 100, 100);
	   		 loc.setText("Enter the request info: ");
	   		 loc.setVisible(true);
	   		 loc.setEditable(false);
	   		 req.add(loc);
	   		 
	   		 String[] locations = {"Gym", "Music Room","Room 1052", "Computer Lab", "Room 1000"};
	   		 JComboBox locList = new JComboBox(locations);
	   		 locList.setVisible(true);
	   		 req.add(locList);
	   		 
	   		 String[] date = {"Monday", "Tuesday", "Wednesday", "Thursday","Friday","Saturday","Sunday"};
	   		 JComboBox dateList = new JComboBox(date);
	   		 dateList.setVisible(true);
	   		 req.add(dateList);
	   		 
	   		 String[] timeslot = {"4PM-5PM", "5PM-6PM", "6PM-7PM", "7PM-8PM", "8PM-9PM", "9PM-10PM"};
	   		 JComboBox timeList = new JComboBox(timeslot);
	   		 timeList.setVisible(true);
	   		 req.add(timeList);
	   		 
	   		 JTextField name = new JTextField();
	   		 name.setText("Enter Your Name");
	   		 name.setVisible(true);
	   		 name.setEditable(true);
	   		 req.add(name);
	   		 
	   		 JCheckBox reoccur = new JCheckBox("Reoccur?");
	   		 reoccur.setVisible(true);
	   		 req.add(reoccur);
	   		 
	   		 JButton submit = new JButton("Submit");
	   		 submit.addActionListener((ActionEvent) -> {
	   			 if(reoccur.isSelected()==true) {
	   				 String text = (String)locList.getSelectedItem() + ", repeating every " + (String)dateList.getSelectedItem() + " between " + (String)timeList.getSelectedItem() + ". Requested by " + name.getText();
	   				 try(PrintStream out = new PrintStream(new FileOutputStream("requests.txt"))) {
	   					 out.print(text);
	   				 } catch (FileNotFoundException e) {
	   					 // TODO Auto-generated catch block
	   					 e.printStackTrace();
	   				 }
	   			 }
	   			else {
	   				String text = (String)locList.getSelectedItem()+", on "+(String)dateList.getSelectedItem() + " between "+(String)timeList.getSelectedItem()+". Requested by "+ name.getText();
	   				try(PrintStream out = new PrintStream(new FileOutputStream("requests.txt"))) {
	   					out.print(text);
	   				} catch (FileNotFoundException e) {
	   					//TODO Auto-generated catch block
	   					e.printStackTrace();
	   				}
	   			}
	   			 requestData.dispose();
	   		 });
	   		 req.add(submit);
	   		 
	   		 requestData.add(req);
	   	 });
	   JButton quitR = new JButton("Logout");
     	quitR.addActionListener((ActionEvent event) -> {
            requestee.dispose();
        	});
	   requesteePanel.add(viewR);
	   requesteePanel.add(reqR);
	   requesteePanel.add(quitR);
	   requestee.add(requesteePanel);
	   requestee.setVisible(true);
   }
   else if (value1.equals("Student") && value2.equals("3")) {
	  JFrame student = new JFrame();
	  student.setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);
	  student.setTitle("Student");
	  student.setSize(150, 150);
	  JPanel studentPanel = new JPanel();
	  JButton viewS = new JButton("View Schedule");
	  	viewS.addActionListener((ActionEvent event) -> {
	  		TableApp3715.table.setEnabled(false);
	  		TableApp3715.window.setVisible(true);
	  	});
	  JButton quitS = new JButton("Logout");
      	quitS.addActionListener((ActionEvent event) -> {
          student.dispose();
      	});
	  studentPanel.add(viewS);
	  studentPanel.add(quitS);
	  student.add(studentPanel);
	  student.setVisible(true);
	  
   }
   else{
   System.out.println("enter the valid username and password");
   JOptionPane.showMessageDialog(this,"Incorrect login or password",
   "Error",JOptionPane.ERROR_MESSAGE);
   }
 }
 }
  class LoginDemo
 {
   public static void main(String arg[])
   {
   try
   {
   Login frame=new Login();
   frame.setSize(300,100);
   frame.setVisible(true);
   }
   catch(Exception e)
   {JOptionPane.showMessageDialog(null, e.getMessage());}
   }
 }
 