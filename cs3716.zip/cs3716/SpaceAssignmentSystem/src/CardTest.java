import java.util.Scanner;
import java.awt.*;
import java.awt.event.*;
import java.text.DateFormat;
import java.time.*;

import javax.swing.*;

public class CardTest implements ItemListener{ 
	JPanel cards;
	final static String Principal = "Principal Login";
	final static String Requestee = "Requestee Login";
	final static String Student = "Student Login";
	
	public void addComponentToPane(Container pane) {
		JPanel comboBoxPane = new JPanel();
		String comboBoxItems[] = { Principal, Requestee, Student };
		JComboBox cb = new JComboBox(comboBoxItems);
		cb.setEditable(false);
        cb.addItemListener(this);
		comboBoxPane.add(cb);
		
		cards = new JPanel(new CardLayout());
		
		   Object rowData0[][] = { { "3:00PM-4:00PM", "Room 1001", "Gym", "Gym", "Music Room", "Room 2025", "Gym, Music Room", "Tennis Court" },
				   				   { "4:00PM-5:00PM", "Room 3001", "Room 3002", "Computer Lab", "Room 2025", "Computer Lab", "Science Lab", "N/A" },
				   				   { "5:00PM-6:00PM", "Art Room", "Art Room", "Gym", "Computer Lab", "N/A", "Gym", "Science Lab" },
				   				   { "6:00PM-7:00PM", "Gym", "Room 2001", "N/A", "Room 2025", "Art Room", "N/A", "Gym" },
				   				   { "7:00PM-8:00PM", "Conference Room", "Music Room", "Pool", "Room 1004", "Gym", "Music Room", "Art Room" },
				   				   { "8:00PM-9:00PM", "Gym", "Pool", "Art Room", "Science Lab", "N/A", "Gym", "Tennis Court" },
				   				   { "9:00PM-10:00PM", "Science Lab", "N/A", "Art Room", "Tennis Court", "N/A", "Pool", "Art Room" },
				   				   { "10:00PM-11:00PM", "Room 2001", "Room 1022", "Gym", "Computer Lab", "Science Lab", "N/A", "Room 1001" } };
		   String[] columnName0 = { "Timeslots", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" };
		   JTable cal0 = new JTable(rowData0, columnName0);
		   JPanel tablePanel0 = new JPanel(new BorderLayout());
		   tablePanel0.add(cal0, BorderLayout.CENTER);
		   tablePanel0.add(cal0.getTableHeader(), BorderLayout.NORTH);
		
        Object rowData[][] = { { "3:00PM-4:00PM", "Room 1001", "Gym", "Gym", "Music Room", "Room 2025", "Gym, Music Room", "Tennis Court" },
        					   { "4:00PM-5:00PM", "Room 3001", "Room 3002", "Computer Lab", "Room 2025", "Computer Lab", "Science Lab", "N/A" },
        					   { "5:00PM-6:00PM", "Art Room", "Art Room", "Gym", "Computer Lab", "N/A", "Gym", "Science Lab" },
        					   { "6:00PM-7:00PM", "Gym", "Room 2001", "N/A", "Room 2025", "Art Room", "N/A", "Gym" },
        					   { "7:00PM-8:00PM", "Conference Room", "Music Room", "Pool", "Room 1004", "Gym", "Music Room", "Art Room" },
                			   { "8:00PM-9:00PM", "Gym", "Pool", "Art Room", "Science Lab", "N/A", "Gym", "Tennis Court" },
                			   { "9:00PM-10:00PM", "Science Lab", "N/A", "Art Room", "Tennis Court", "N/A", "Pool", "Art Room" },
                			   { "10:00PM-11:00PM", "Room 2001", "Room 1022", "Gym", "Computer Lab", "Science Lab", "N/A", "Room 1001" } };
        String[] columnName = { "Timeslots", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" };
        JTable cal = new JTable(rowData, columnName);
        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.add(cal, BorderLayout.CENTER);
        tablePanel.add(cal.getTableHeader(), BorderLayout.NORTH);
		
        JButton viewP = new JButton("View Calendar");
        viewP.addActionListener((ActionEvent event) -> {
        	new TableApp();
        });
        
        JButton viewR = new JButton("View Calendar");
        viewR.addActionListener((ActionEvent event) -> {
        	new TableApp();
        });
        
        JButton viewS = new JButton("View Calendar");
        viewS.addActionListener((ActionEvent event) -> {
        	new TableApp();
        });
        
        JButton modify = new JButton("Modify Calendar");
        modify.addActionListener((ActionEvent event) -> {
            JFrame modifyData = new JFrame();
            modifyData.setTitle("Modify Calendar");
            modifyData.setSize(500, 500);
            modifyData.setLocationRelativeTo(null);
            modifyData.setVisible(true);
            
            JTextField xcord = new JTextField();
            xcord.setText("Enter the x position(starting at 1, ending at 8): ");
            xcord.setBounds(100, 100, 100, 100);
            
            JTextField ycord = new JTextField();
            ycord.setText("Enter the y position(Between 0-7): ");
            ycord.setBounds(100, 200, 100, 100);
            
            JTextField slotinfo = new JTextField();
            slotinfo.setText("Enter name of desired room: ");
            slotinfo.setBounds(100, 300, 100, 100);
            
            JPanel modifyPanel = new JPanel();
            modifyPanel.setLocation(0,0);
            modifyPanel.setSize(500, 500);
            modifyPanel.setVisible(true);
            
            modifyPanel.add(xcord);
            modifyPanel.add(ycord);
            modifyPanel.add(slotinfo);
            
            JButton addReq = new JButton("Add");
            JButton remReq = new JButton("Remove");
            
            addReq.setSize(50, 100);
            remReq.setSize(50, 100);
            

            
            modifyPanel.add(addReq);
            modifyPanel.add(remReq);
            modifyData.add(modifyPanel);

            
        });
        
        JButton request = new JButton("Request Timeslot");
        request.addActionListener((ActionEvent event) -> {
            JFrame requestData = new JFrame();
            requestData.setTitle("Request Timeslots");
            requestData.setSize(500, 500);
            requestData.setLocationRelativeTo(null);
            requestData.setVisible(true);
            
            JPanel req = new JPanel();
            req.setSize(500,500);
            req.setVisible(true);
            
            JTextField loc = new JTextField();
            loc.setBounds(100,100,100,100);
            loc.setText("Enter the Desired Location :");
            loc.setVisible(true);
            loc.setEditable(true);
            req.add(loc);
            
            JTextField time = new JTextField();
            time.setText("Enter the desired timeslot :");
            time.setVisible(true);
            time.setEditable(true);
            req.add(time );
            
            JButton submit = new JButton("Submit");
            submit.addActionListener((ActionEvent) -> {
            	requestData.dispose();
            });
            req.add(submit);
            
            
            requestData.add(req);         
        });

        JButton quitP = new JButton("Quit");
        quitP.addActionListener((ActionEvent event) -> {
            System.exit(0);
        });
        
        JButton quitR = new JButton("Quit");
        quitR.addActionListener((ActionEvent event) -> {
            System.exit(0);
        });
        
        JButton quitS = new JButton("Quit");
        quitS.addActionListener((ActionEvent event) -> {
            System.exit(0);
        });
		
		JPanel cardP = new JPanel();
		cardP.add(viewP);
		cardP.add(modify);
		cardP.add(quitP);
		
		cards.add(cardP, Principal);
		
		JPanel cardR = new JPanel();
		cardR.add(viewR);
		cardR.add(request);
		cardR.add(quitR);
		
		JPanel cardS = new JPanel();
		cardS.add(viewS);
		cardS.add(quitS);
		
		cards = new JPanel(new CardLayout());
		cards.add(cardP, Principal);
		cards.add(cardR, Requestee);
		cards.add(cardS, Student);
		
		pane.add(comboBoxPane, BorderLayout.PAGE_START);
		pane.add(cards, BorderLayout.CENTER);
	}
	
	public void itemStateChanged(ItemEvent evt) {
		CardLayout c1 = (CardLayout)(cards.getLayout());
		c1.show(cards,  (String)evt.getItem());
	}
	
	private static void createANDdisplay() {
		JFrame frame = new JFrame("Space Assignment System");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		CardTest test = new CardTest();
		test.addComponentToPane(frame.getContentPane());
		
		frame.pack();
		frame.setVisible(true);
	}
	
	public static void main(String[] args) {
		
		Scanner input = new Scanner(System.in);
		
		String username;
		String password;
		
		System.out.println("Welcome to the Space Assignment System");
		System.out.println("Log in: ");
		
		System.out.println("Username: ");
		username = input.next();
		
		System.out.println("Password: ");
		password = input.next();
		
		if(username.equals(username) && password.equals(password)){
			
			javax.swing.SwingUtilities.invokeLater(new Runnable() {
				public void run() {
					createANDdisplay();
				}
			});
		}
		else{
			System.out.println("Incorrect Login Information.");
		}
	}
}
