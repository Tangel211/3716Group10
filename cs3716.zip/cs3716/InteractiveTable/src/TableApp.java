//package cs3716project;

import javax.swing.JFrame;
import javax.swing.JTable;
import javax.swing.JScrollPane;
import javax.swing.JLabel;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.DefaultTableCellRenderer;
import java.awt.GridLayout;
import java.awt.Color;
import java.awt.Component;

public class TableApp extends CardTest{
	static JFrame window = new JFrame();
	static JLabel label = new  JLabel();
	static DefaultTableModel table_model = new DefaultTableModel( new Object[][] { { "3:00PM-4:00PM", "Room 1001", "Gym", "Gym", "Music Room", "Room 2025", "Gym, Music Room", "Tennis Court" },
				   { "4:00PM-5:00PM", "Room 3001", "Room 3002", "Computer Lab", "Room 2025", "Computer Lab", "Science Lab", "N/A" },
				   { "5:00PM-6:00PM", "Art Room", "Art Room", "Gym", "Computer Lab", "N/A", "Gym", "Science Lab" },
				   { "6:00PM-7:00PM", "Gym", "Room 2001", "N/A", "Room 2025", "Art Room", "N/A", "Gym" },
				   { "7:00PM-8:00PM", "Conference Room", "Music Room", "Pool", "Room 1004", "Gym", "Music Room", "Art Room" },
    			   { "8:00PM-9:00PM", "Gym", "Pool", "Art Room", "Science Lab", "N/A", "Gym", "Tennis Court" },
    			   { "9:00PM-10:00PM", "Science Lab", "N/A", "Art Room", "Tennis Court", "N/A", "Pool", "Art Room" },
    			   { "10:00PM-11:00PM", "Room 2001", "Room 1022", "Gym", "Computer Lab", "Science Lab", "N/A", "Room 1001" } },
				   
				   new Object[]{ "Timeslots", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday" });
	static JTable table = new JTable(table_model);
	TableApp() {
		table.setDefaultRenderer(Object.class, new Painting());
		table.getTableHeader().setBackground(new Color (135,206,250));
		table.setForeground(Color.BLUE);
		window.setSize(500,300);
		window.setLayout(new GridLayout (2,1));
		window.add(new JScrollPane(table));
		window.add(label);
		window.setLocationRelativeTo(null);
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		window.setVisible(true);
	}
	static class Painting extends DefaultTableCellRenderer {
		public Component getTableCellRendererComponent(JTable table,Object value,boolean isSelected,boolean hasFocus,int row, int coloumn) {
			Component c = super.getTableCellRendererComponent(table,value,isSelected,hasFocus,row,coloumn);
			
			
			if (!hasFocus){
				if (coloumn == 0)
					c.setBackground(new Color(255,228,181));
				else if (coloumn==1)
					c.setBackground(new Color (224,255,255));
				else if (coloumn==2)
					c.setBackground(new Color (225,255,224));
			}else{
				c.setBackground(new Color(20,255,20));
				label.setText("   " + table.getColumnName(table.getSelectedColumn())
								+", "+ table_model.getValueAt(table.getSelectedRow(),0) +" : " +(String)table_model.getValueAt(table.getSelectedRow(),table.getSelectedColumn()));
			} 
			return c;
		}
	}
	
	public static void main (String [] args ) {
		
		new TableApp();
		}
}
